local PREVENT_SHUFFLE_FLAG = 184
local SHUFFLE_TASK = 165

local allowshuffle = false
local playerped = nil
local currentvehicle = nil

local enterData = nil

local function getSeatPedIsIn(ped, veh)
    if veh == 0 then return nil end
    local seats = GetVehicleModelNumberOfSeats(GetEntityModel(veh))
    for seat = -1, (seats - 2) do
        if GetPedInVehicleSeat(veh, seat) == ped then
            return seat
        end
    end
    return nil
end

local function adjacentSeatSameRow(seat)
    if seat == -1 then return 0 end
    if seat == 0 then return -1 end
    if seat == 1 then return 2 end
    if seat == 2 then return 1 end
    return nil
end

local function safeSetPedIntoSeat(ped, veh, seat)
    if veh == 0 or seat == nil then return false end
    local occ = GetPedInVehicleSeat(veh, seat)
    if occ ~= 0 and occ ~= ped then
        return false
    end
    SetPedIntoVehicle(ped, veh, seat)
    return true
end

local function inferSeatFromClosestDoor(ped, veh)
    local p = GetEntityCoords(ped)
    local bestDoor, bestDist = nil, nil

    for door = 0, 3 do
        local ep = GetEntryPositionOfDoor(veh, door)
        if ep and (ep.x ~= 0.0 or ep.y ~= 0.0 or ep.z ~= 0.0) then
            local d = #(p - ep)
            if not bestDist or d < bestDist then
                bestDist = d
                bestDoor = door
            end
        end
    end

    if bestDoor == 0 then return -1 end 
    if bestDoor == 1 then return 0 end  
    if bestDoor == 2 then return 1 end  
    if bestDoor == 3 then return 2 end  
    return nil
end

CreateThread(function()
    while true do
        Wait(100)
        playerped = PlayerPedId()
        currentvehicle = GetVehiclePedIsIn(playerped, false)
    end
end)

CreateThread(function()
    while true do
        Wait(0)

        if not playerped then
            goto continue
        end

        if IsPedGettingIntoAVehicle(playerped) then
            local vehTrying = GetVehiclePedIsTryingToEnter(playerped)
            if vehTrying ~= 0 and DoesEntityExist(vehTrying) then
                local seatTrying = GetSeatPedIsTryingToEnter(playerped)
                local inferred = inferSeatFromClosestDoor(playerped, vehTrying)

                local intendedSeat = inferred or seatTrying

                enterData = {
                    veh = vehTrying,
                    seat = intendedSeat,
                    untilTime = GetGameTimer() + 5000
                }
            end
        end

        if IsPedInAnyVehicle(playerped, false) or IsPedGettingIntoAVehicle(playerped) then
            SetPedConfigFlag(playerped, PREVENT_SHUFFLE_FLAG, not allowshuffle)
        else
            enterData = nil
            allowshuffle = false
            SetPedConfigFlag(playerped, PREVENT_SHUFFLE_FLAG, false)
        end

        if IsPedInAnyVehicle(playerped, false) and not allowshuffle and currentvehicle ~= 0 then
            if enterData and GetGameTimer() <= enterData.untilTime then
                if GetVehiclePedIsIn(playerped, false) == enterData.veh then
                    local curSeat = getSeatPedIsIn(playerped, currentvehicle)
                    if curSeat ~= nil and enterData.seat ~= nil and curSeat ~= enterData.seat then
                        if IsVehicleSeatFree(currentvehicle, enterData.seat) then
                            safeSetPedIntoSeat(playerped, currentvehicle, enterData.seat)
                            enterData = nil
                        else
                            enterData = nil
                        end
                    else
                        enterData = nil
                    end
                end
            else
                enterData = nil
            end

            if GetIsTaskActive(playerped, SHUFFLE_TASK) then
                local seatNow = getSeatPedIsIn(playerped, currentvehicle)
                if seatNow ~= nil then
                    safeSetPedIntoSeat(playerped, currentvehicle, seatNow)
                end
            end
        end

        ::continue::
    end
end)

local function doShuffle()
    if not playerped or not IsPedInAnyVehicle(playerped, false) then
        return
    end

    local veh = GetVehiclePedIsIn(playerped, false)
    if veh == 0 then return end

    local seat = getSeatPedIsIn(playerped, veh)
    if seat == nil then return end

    local targetSeat = adjacentSeatSameRow(seat)
    if not targetSeat then
        return
    end

    if not IsVehicleSeatFree(veh, targetSeat) then
        return
    end

    allowshuffle = true
    SetPedConfigFlag(playerped, PREVENT_SHUFFLE_FLAG, false)

    TaskShuffleToNextVehicleSeat(playerped, veh)

    local start = GetGameTimer()
    local timeout = (Config and Config.ShuffleTimeoutMs) or 4500

    while (GetGameTimer() - start) < timeout do
        Wait(0)

        if not IsPedInAnyVehicle(playerped, false) then
            break
        end

        local curVeh = GetVehiclePedIsIn(playerped, false)
        if curVeh ~= veh then
            break
        end

        local curSeat = getSeatPedIsIn(playerped, veh)
        if curSeat ~= nil and curSeat ~= seat then
            if curSeat == targetSeat then
                enterData = nil
                allowshuffle = false
                SetPedConfigFlag(playerped, PREVENT_SHUFFLE_FLAG, true)
                return
            else
                safeSetPedIntoSeat(playerped, veh, seat)
                allowshuffle = false
                SetPedConfigFlag(playerped, PREVENT_SHUFFLE_FLAG, true)
                return
            end
        end
    end

    allowshuffle = false
    SetPedConfigFlag(playerped, PREVENT_SHUFFLE_FLAG, true)
end

RegisterNetEvent("SeatShuffle")
AddEventHandler("SeatShuffle", function()
    doShuffle()
end)

RegisterCommand((Config and Config.CommandName) or "shuffle", function()
    doShuffle()
end, false)

RegisterKeyMapping(
    (Config and Config.CommandName) or "shuffle",
    "Shuffle Seat (Adjacent Only)",
    "keyboard",
    (Config and Config.DefaultKey) or "B"
)
