local PREVENT_SHUFFLE_FLAG = 184
local SHUFFLE_TASK = 165

local allowshuffle = false
local playerped = nil
local currentvehicle = nil
local lockedSeat = nil

local function notify(msg)
    BeginTextCommandThefeedPost("STRING")
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandThefeedPostTicker(false, false)

    TriggerEvent("chat:addMessage", {
        color = { 255, 255, 255 },
        args = { Config.NotifyPrefix or "^3Seat^7", msg }
    })
end

local function getSeatPedIsIn(ped, veh)
    if veh == 0 then return nil end
    local seats = GetVehicleModelNumberOfSeats(GetEntityModel(veh))
    for seat = -1, (seats - 2) do
        if GetPedInVehicleSeat(veh, seat) == ped then
            return seat
        end
    end
    return nil
end

local function adjacentSeatSameRow(seat)
    if seat == -1 then return 0 end
    if seat == 0 then return -1 end
    if seat == 1 then return 2 end
    if seat == 2 then return 1 end
    return nil
end

CreateThread(function()
    while true do
        Wait(150)
        playerped = PlayerPedId()
        currentvehicle = GetVehiclePedIsIn(playerped, false)
    end
end)

CreateThread(function()
    while true do
        Wait(0)

        if not playerped then
            goto continue
        end

        if IsPedInAnyVehicle(playerped, false) then
            if not allowshuffle then
                SetPedConfigFlag(playerped, PREVENT_SHUFFLE_FLAG, true)

                if currentvehicle ~= 0 then
                    if not lockedSeat then
                        lockedSeat = getSeatPedIsIn(playerped, currentvehicle)
                    end

                    if lockedSeat ~= nil then
                        local curSeat = getSeatPedIsIn(playerped, currentvehicle)
                        if curSeat ~= nil and curSeat ~= lockedSeat then
                            SetPedIntoVehicle(playerped, currentvehicle, lockedSeat)
                        end
                    end

                    if GetIsTaskActive(playerped, SHUFFLE_TASK) then
                        local seatNow = getSeatPedIsIn(playerped, currentvehicle)
                        if seatNow ~= nil then
                            SetPedIntoVehicle(playerped, currentvehicle, seatNow)
                        end
                    end
                end
            end
        else
            lockedSeat = nil
            allowshuffle = false
            SetPedConfigFlag(playerped, PREVENT_SHUFFLE_FLAG, false)
        end

        ::continue::
    end
end)

local function doShuffle()
    if not playerped or not IsPedInAnyVehicle(playerped, false) then
        return
    end

    local veh = GetVehiclePedIsIn(playerped, false)
    if veh == 0 then return end

    local seat = getSeatPedIsIn(playerped, veh)
    if seat == nil then return end

    local targetSeat = adjacentSeatSameRow(seat)
    if not targetSeat then
        notify("You can only shuffle to the seat next to you.")
        return
    end

    if not IsVehicleSeatFree(veh, targetSeat) then
        notify("The seat next to you is not empty.")
        return
    end

    allowshuffle = true
    SetPedConfigFlag(playerped, PREVENT_SHUFFLE_FLAG, false)

    TaskShuffleToNextVehicleSeat(playerped, veh)

    local start = GetGameTimer()
    local timeout = Config.ShuffleTimeoutMs or 4500

    while (GetGameTimer() - start) < timeout do
        Wait(0)

        if not IsPedInAnyVehicle(playerped, false) then
            break
        end

        local curVeh = GetVehiclePedIsIn(playerped, false)
        if curVeh ~= veh then
            break
        end

        local curSeat = getSeatPedIsIn(playerped, veh)
        if curSeat and curSeat ~= seat then
            if curSeat == targetSeat then
                lockedSeat = targetSeat
                allowshuffle = false
                SetPedConfigFlag(playerped, PREVENT_SHUFFLE_FLAG, true)
                return
            else
                SetPedIntoVehicle(playerped, veh, seat)
                lockedSeat = seat
                allowshuffle = false
                SetPedConfigFlag(playerped, PREVENT_SHUFFLE_FLAG, true)
                return
            end
        end
    end

    allowshuffle = false
    SetPedConfigFlag(playerped, PREVENT_SHUFFLE_FLAG, true)
end

RegisterNetEvent("SeatShuffle")
AddEventHandler("SeatShuffle", function()
    doShuffle()
end)

RegisterCommand(Config.CommandName or "shuffle", function()
    doShuffle()
end, false)

RegisterCommand("shuff", function()
    doShuffle()
end, false)

RegisterKeyMapping(
    Config.CommandName or "shuffle",
    "Shuffle Seat (Adjacent Only)",
    "keyboard",
    Config.DefaultKey or "B"
)
