Config = {}

Config.CommandName = "shuffle"
Config.DefaultKey = "B"
Config.ShuffleTimeoutMs = 4500
Config.NotifyPrefix = "^3Seat^7"
