fx_version 'cerulean'
game 'gta5'

author 'Cowboy - Echo Kilo Studios'
description 'Anti Seat Shuffle'
version '1.0.0'

client_scripts {
    'shared/config.lua',
    'client/client.lua'
}
