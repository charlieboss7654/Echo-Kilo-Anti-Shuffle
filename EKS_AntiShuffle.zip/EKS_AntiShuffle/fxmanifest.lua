fx_version 'cerulean'
game 'gta5'

author 'EKS Scripts'
description 'Anti Seat Shuffle'
version '1.0.0'

client_scripts {
    'shared/config.lua',
    'client/client.lua'
}
